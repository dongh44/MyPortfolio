Fs = 3000;
%t = 0:1/Fs:3;
[m, Fs] = audioread('zekai.mp3');
Ts=1/Fs
t=1:length(m);
%sound(m,Fs,16);
%plot(t,m);
stepsize = 1/5;
mod = dm_mod(m,stepsize);
%plot(t,mod);
%sound(mod,Fs,16);

[b,a]=butter(2,0.1,'low');
demod=filter(b,a,mod);
%sound(demod,Fs);
plot(t,demod)
%demod = dm_demod(stepsize,Fs,mod);

%%t=1:length(demod);
%plot(t,m_out);
%sound(m_out,Fs,16);

%error = dm_error(m, demod);
%sound(demod-m',Fs,16);
%plot(t,demod-m);

