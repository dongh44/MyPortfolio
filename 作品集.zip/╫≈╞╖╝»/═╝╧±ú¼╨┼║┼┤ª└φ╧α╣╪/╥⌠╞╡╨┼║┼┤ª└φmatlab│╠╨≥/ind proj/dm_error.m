function [e] = dm_error(m, m_out)
len1 = length(m);
e(1) = 0;
for k = 0:len1
    e(k) = m(k) - m_out(k);
end
end