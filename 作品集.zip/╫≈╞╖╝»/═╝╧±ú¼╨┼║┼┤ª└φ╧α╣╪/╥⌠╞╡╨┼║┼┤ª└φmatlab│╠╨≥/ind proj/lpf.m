function [a] = lpf(tap,cf,demod)
b = fir1(tap,cf);
a = conv2(demod, b, 'same');
end