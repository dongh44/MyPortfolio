function [x] = dm_mod(m,stepsize)
Fs = 3000;
mlen = length(m);
y(1) = 0;
for i = 1:mlen
    if(m(i) >= y(i))
    x(i) = 1;
    y(i+1) = y(i) + x(i)*stepsize;
    else
    x(i) = -1;
    y(i+1) = y(i) + x(i)*stepsize;
end
end