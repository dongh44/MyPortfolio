function [z] = dm_demod(stepsize, Fs, mod)
mlen = length(mod);
Ts= 1/Fs;
v(1) = 0;
for j = 1:mlen;
    if(mod(j)==0)
    v(j+1) = v(j) + stepsize;
    else
    v(j+1) = v(j) - stepsize;
end
end
z = v(2:mlen-1);
    