function [Xn,Y,Jud]=cal(X,Y,K,B,N,n,Jud)
Num=[];
Z=[];
Xn=cell(n,1);
Yl=length(Y);
for i=1:n
    NumTemp=X{i,1};
    NumTempn=(NumTemp>=K);
    if ~NumTempn
        Jud=0;
        break
    end
    NumTempb=NumTemp(NumTempn);
    Num=[Num,NumTempb];
end
if Jud
    K1=min(Num);
    for i=1:n
        NumTemp=X{i,1};
        NumTempn=(NumTemp>=K);
        TempMin=min(NumTemp(NumTempn));
        NumTemp(NumTemp==TempMin)=NumTemp(NumTemp==TempMin)-K1;
        Xn{i,1}=NumTemp;
        TempYn=B(i)*N*(X{i,1}-Xn{i,1});
        for j=1:length(TempYn)
            Y{Yl+i,j}=TempYn(j);
        end
        Z=[Z,TempYn(TempYn>0)];
    end   
end
Z=min(Z);
Y{Yl+n+1,1}=[Z];